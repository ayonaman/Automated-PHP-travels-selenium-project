package frameworkPackage;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Browser {
public static WebDriver driver;

public Browser() {

}

public static WebDriver getDriver(String browserName) {

			if(browserName.equalsIgnoreCase("Edge")) {
				
			System.setProperty("webdriver.edge.driver", "C:\\Users\\namanj\\Downloads\\edgedriver_win64\\msedgedriver.exe");
			driver = new EdgeDriver();
			
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			
			}
			
			return driver;
}
}
			



